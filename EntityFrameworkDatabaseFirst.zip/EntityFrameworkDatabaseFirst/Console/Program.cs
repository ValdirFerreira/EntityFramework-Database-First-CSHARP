﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Console
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var bancoDadosEntities = new BancoDadosEntities())
            {
                var usuario = bancoDadosEntities.Usuarios_selecionarPeloId(1);
            }
        }
    }
}
